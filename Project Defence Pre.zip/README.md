# QUT-Beamer-Theme
LaTeX beamer theme for Queensland University of Technology.  This template mostly comes from Jiayi Weng, Trinkle23897. 
The original GitHub repo is https://github.com/Trinkle23897/THU-Beamer-Theme.
